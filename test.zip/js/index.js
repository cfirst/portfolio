/*
$(document).ready(function(){
	$(".porftolio-image").on("click",function() {});
	window.location.href="www.facebook.com";
	return false;
});
*/